package com.example.reg;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    Button guardar;
    EditText nombre,apellido,dir,ci,mail;
    private DatabaseReference mDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        guardar = (Button) findViewById(R.id.btnGuardar);
        nombre=(EditText) findViewById(R.id.nombreText);
        apellido=(EditText) findViewById(R.id.apellidoText);
        dir=(EditText) findViewById(R.id.dirText);
        ci=(EditText) findViewById(R.id.cedulaText);
         mail=(EditText) findViewById(R.id.mailText);
        mDatabase = FirebaseDatabase.getInstance().getReference();

        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datos();
            }
        });

    }

    private  void datos(){
        nuevoU(nombre.getText().toString(),apellido.getText().toString(),ci.getText().toString(),mail.getText().toString(),dir.getText().toString(),"","");
    }

    private void nuevoU(String nombre, String apell, String ci,String mail,String dir,String img,String vid) {

        if(nombre.isEmpty()==true ||apell.isEmpty()==true||ci.isEmpty()==true||mail.isEmpty()==true||dir.isEmpty()==true ){
            Toast.makeText(this, "No se puede Guardar", Toast.LENGTH_SHORT).show();
        }
        else{
            Usuario user = new Usuario(nombre,apell,ci,mail,dir,img,vid);

            mDatabase.child("Usuario").child(ci).setValue(user);
            Toast.makeText(this, "Datos Guardados", Toast.LENGTH_SHORT).show();
        }
    }

}