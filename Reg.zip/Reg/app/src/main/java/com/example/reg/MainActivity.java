package com.example.reg;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    Button guardar;
    EditText nombreU,apellidoU,direcc,ced,mailU;
    Usuario a=new Usuario();
    private DatabaseReference mDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        guardar = (Button) findViewById(R.id.btnGuardar);
        nombreU=(EditText) findViewById(R.id.nombreText);
        apellidoU=(EditText) findViewById(R.id.apellidoText);
        direcc=(EditText) findViewById(R.id.dirText);
        ced=(EditText) findViewById(R.id.cedulaText);
        mailU=(EditText) findViewById(R.id.mailText);
        mDatabase = FirebaseDatabase.getInstance().getReference();

        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datos();
            }
        });

    }

    private  void datos(){
        a.setNombre(nombreU.getText().toString());
        a.setApellido(apellidoU.getText().toString());
        a.setCedula(ced.getText().toString());
        a.setMail(mailU.getText().toString());
        a.setDireccion(direcc.getText().toString());
        a.setImg("");
        a.setVid("");
        nuevoU(a.getNombre(),a.getApellido(),a.getCedula(),a.getMail(),a.getDireccion(),"","");
    }

    private void nuevoU(String nombre, String apell, String ci,String mail,String dir,String img,String vid) {

        if(nombre.isEmpty()==true ||apell.isEmpty()==true||ci.isEmpty()==true||mail.isEmpty()==true||dir.isEmpty()==true ){
            Toast.makeText(this, "No se puede Guardar", Toast.LENGTH_SHORT).show();
        }
        else{

            mDatabase.child("Usuario").child(ci).setValue(a);
            Toast.makeText(this, "Datos Guardados", Toast.LENGTH_SHORT).show();
        }
    }

}