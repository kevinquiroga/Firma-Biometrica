package com.example.reg;

public class Usuario {

    public String nombre;
    public String apellido;
    public String direccion;
    public String cedula;
    public String mail;
    public String img;
    public String vid;


    public Usuario() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public Usuario(String nombre, String apellido,String direccion,String cedula,String mail,String img,String vid) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.cedula = cedula;
        this.mail = mail;
        this.img = img;
        this.vid = vid;
    }
}
